#!/bin/bash

AXRT=libaxrt-4.0_41.12-1_amd64.deb
OWBLIBS=OWB-Libs-for-x86_64-axrt.zip
OWB=owb-2.1.x86_64-aros-v11.zip

cd /tmp

wget https://axrt.org/download/axrt/4.0/packages/"${AXRT}" -O "${AXRT}"
wget https://axrt.org/download/axrt/4.0/other/"${OWBLIBS}" -O "${OWBLIBS}"
wget https://axrt.org/download/axrt/4.0/other/StartOWB -O StartOWB
wget https://archives.aros-exec.org/share/network/browser/"${OWB}" -O "${OWB}"

sudo dpkg -i "${AXRT}"

chmod +x StartOWB
./StartOWB

sudo apt -y install unzip

unzip -o "${OWBLIBS}" -d ~/SYS/
unzip -o "${OWB}" -d ~/Work/

mv StartOWB ~/Work/owb-x86_64/
cp -f ~/Work/owb-x86_64/OWB.info.axrt ~/Work/owb-x86_64/OWB.info
rm -f "${OWBLIBS}"
rm -f "${OWB}"
rm -f "${AXRT}"

cat > ~/.asoundrc << EOF
pcm.default pulse
ctl.default pulse
EOF

sudo apt -y install libasound2-plugins
